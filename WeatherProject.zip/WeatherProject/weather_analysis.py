
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# Project folder
folder = Path(r"C:\WeatherProject")
csv_file = folder / "weather_clean.csv"

# Load the CSV
df = pd.read_csv(csv_file)

# Remove accidental spaces from column names
df.columns = df.columns.str.strip()

# Convert time column to datetime
df["time"] = pd.to_datetime(df["time"], errors="coerce")
df = df.dropna(subset=["time"])

# Extract month
df["month"] = df["time"].dt.to_period("M").astype(str)

# Calculate monthly weather statistics
monthly = df.groupby("month").agg(
    avg_temp=("temperature_2m (°C)", "mean"),
    avg_humidity=("relative_humidity_2m (%)", "mean"),
    total_rain=("precipitation (mm)", "sum"),
    avg_wind=("wind_speed_10m (km/h)", "mean")
).round(2)

# Display results
print("\nMONTHLY WEATHER ANALYSIS")
print(monthly.to_string())

# Save summary
monthly.to_csv(folder / "monthly_weather_analysis.csv")

# Temperature chart
monthly["avg_temp"].plot(
    marker="o",
    title="Monthly Average Temperature - Ranchi"
)
plt.xlabel("Month")
plt.ylabel("Temperature (°C)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(folder / "monthly_temperature.png")
plt.show()
plt.close()

# Rainfall chart
monthly["total_rain"].plot(
    kind="bar",
    title="Monthly Total Precipitation - Ranchi"
)
plt.xlabel("Month")
plt.ylabel("Precipitation (mm)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(folder / "monthly_rainfall.png")
plt.show()
plt.close()

print("\nAnalysis completed for Ranchi!")
print("Results saved in C:\\WeatherProject")


LOAD DATA
INFILE 'C:\WeatherProject\weather_clean.csv'
APPEND
INTO TABLE weather_data
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
TRAILING NULLCOLS
(
    observation_time      CHAR(16),
    temperature_2m        DECIMAL EXTERNAL,
    relative_humidity_2m  DECIMAL EXTERNAL,
    dew_point_2m          DECIMAL EXTERNAL,
    apparent_temperature  DECIMAL EXTERNAL,
    precipitation_mm      DECIMAL EXTERNAL,
    rain_mm               DECIMAL EXTERNAL,
    snowfall_cm           DECIMAL EXTERNAL,
    wind_speed_10m        DECIMAL EXTERNAL,
    cloud_cover           DECIMAL EXTERNAL
)
